import os
import csv
# Path to collect data from the Resources folder
election_csv = os.path.join('C:/Users/Prajakta/Desktop/UofT/Python/election_data.csv')
# Read in the CSV file
winnie =[]
with open(election_csv, newline="") as csvfile:
    csvreader = csv.reader(csvfile,delimiter=",")
    print(csvreader)
    
    poll_header = next(csvreader)
    print(f'csv_header:{poll_header}')
    
    for row in csvreader:
        if row[2] not in winnie:
            winnie.append(row)

    khan = []
    correy = []
    li = []
    otooley = []
    
    winner = 0 
    results = []

    #khan_votes = []
    #correy_votes = []
    #li_votes = []
    #otooley_votes = []

    khan_votes = 0
    correy_votes = 0
    li_votes = 0
    otooley_votes = 0

     
    for row in csvreader:
        if row [2] == "Khan":
            khan_votes = khan_votes + 1
        elif row [2] == "Correy":
            correy_votes = correy_votes + 1
        elif row [2] == "Li":
            li_votes = li_votes + 1
        else:
            otooley_votes = otooley_votes + 1
    
     
# Calculating Total Votes
total_votes = khan_votes + correy_votes + li_votes + otooley_votes
print(total_votes)
#Calculating percentage per candidate 
khan_percentage = (khan_votes/total_votes)*100
correy_percentage = (correy_votes/total_votes)*100
li_percentage = (li_votes/total_votes)*100
otooley_percentage = (otooley_votes/total_votes)*100
results = [khan_percentage, correy_percentage, li_percentage, otooley_percentage]

for x in results: 
     if x > winner:
          winner = x


# final output
print ("Election Results")
print ("--------------------")
print (f"Total Votes: {total_votes}")
print (f"Khan: {khan_percentage:.2f}% ({khan_votes})")
print (f"Correy: ({correy_percentage:.2f}% ({correy_votes})")
print (f"Li: {li_percentage:.2f}% ({li_votes})")
print (f"O'Tooley: {otooley_percentage:.2f}% ({otooley_votes})")
print ("--------------------")
print (f"Winner:{winnie[results.index(winner)]}")
print ("--------------------")