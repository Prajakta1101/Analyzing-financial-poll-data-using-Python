import os
import csv

# Path to collect data from the Resources folder
pybank_csv = os.path.join("C:/Users/Prajakta/Desktop/UofT/Python/PyBank.csv")

# Read in the CSV file
with open(pybank_csv, 'r') as csvfile:
    # Split the data on commas
    csvreader = csv.reader(csvfile, delimiter=',')

    header = next(csvreader)

    dates = []
    months = []
    total_profit = 0
    total_monthly_change = 0

    # Loop through the data
    for row in csvreader:
        date = row[0]
        dates.append(date)
        month = row[1]
        months.append(month)
        total_profit = total_profit + int(month)

        monthly_change = [int(months[i + 1]) - int(months[i]) for i in range(len(months)-1)] 

    max = 0
    min = 0

    for month in monthly_change:
        total_monthly_change = total_monthly_change + month
    
    average = float("{0:.2f}".format(total_monthly_change/len(monthly_change)))
    
    for month in monthly_change:
        if int(month) > max:
            max = int(month)
    

    for month in monthly_change:
        if int(month) < min:
            min = int(month)

# Final Analysis    
print ("Financial Analysis")
print ("----------------------------")
print (f"Total Months: {len(months)}")
print (f"Total: ${total_profit}")
print (f"Average Change: ${average}")
print (f"Greatest Increase in Profits: {dates[monthly_change.index(max)+1]} ${max}")
print (f"Greatest Decrease in Profits: {dates[monthly_change.index(min)+1]} ${min}")

output_file = os.path.join("C:/Users/Prajakta/Desktop/UofT/Python/Financial_Analysis.txt")
